﻿namespace Suma_de_numeros
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sumar = new Button();
            tx1 = new TextBox();
            tx2 = new TextBox();
            restar = new Button();
            limpiar = new Button();
            lstHistorial = new ListBox();
            SuspendLayout();
            // 
            // sumar
            // 
            sumar.BackColor = SystemColors.ActiveBorder;
            sumar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sumar.Location = new Point(319, 42);
            sumar.Name = "sumar";
            sumar.Size = new Size(75, 23);
            sumar.TabIndex = 0;
            sumar.Text = "Sumar";
            sumar.UseVisualStyleBackColor = false;
            sumar.Click += sumar_Click;
            // 
            // tx1
            // 
            tx1.Location = new Point(197, 42);
            tx1.Name = "tx1";
            tx1.Size = new Size(100, 23);
            tx1.TabIndex = 1;

            // 
            // tx2
            // 
            tx2.Location = new Point(197, 114);
            tx2.Name = "tx2";
            tx2.Size = new Size(100, 23);
            tx2.TabIndex = 2;
            // 
            // restar
            // 
            restar.BackColor = SystemColors.ActiveBorder;
            restar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            restar.Location = new Point(319, 81);
            restar.Name = "restar";
            restar.Size = new Size(75, 23);
            restar.TabIndex = 3;
            restar.Text = "Restar";
            restar.UseVisualStyleBackColor = false;
            restar.Click += restar_Click;
            // 
            // limpiar
            // 
            limpiar.BackColor = SystemColors.ActiveBorder;
            limpiar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            limpiar.Location = new Point(319, 124);
            limpiar.Name = "limpiar";
            limpiar.Size = new Size(75, 23);
            limpiar.TabIndex = 5;
            limpiar.Text = "Limpiar";
            limpiar.UseVisualStyleBackColor = false;
            limpiar.Click += limpiar_Click;
            // 
            // lstHistorial
            // 
            lstHistorial.FormattingEnabled = true;
            lstHistorial.ItemHeight = 15;
            lstHistorial.Location = new Point(11, 12);
            lstHistorial.Name = "lstHistorial";
            lstHistorial.Size = new Size(180, 169);
            lstHistorial.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InactiveCaption;
            ClientSize = new Size(423, 193);
            Controls.Add(lstHistorial);
            Controls.Add(limpiar);
            Controls.Add(restar);
            Controls.Add(tx2);
            Controls.Add(tx1);
            Controls.Add(sumar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Form1";
            Text = "Suma_Resta";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button sumar;
        private TextBox tx1;
        private TextBox tx2;
        private Button restar;
        private Button limpiar;
        private ListBox lstHistorial;
    }
}
