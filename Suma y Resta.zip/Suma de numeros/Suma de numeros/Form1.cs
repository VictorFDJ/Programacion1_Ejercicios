namespace Suma_de_numeros
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

       
        private bool ValidarEntradas(out double numero1, out double numero2)
        {
            bool esValido = true;
            numero1 = 0;
            numero2 = 0;

            if (!double.TryParse(tx1.Text, out numero1))
            {
                MessageBox.Show("Ingrese un n�mero v�lido en el campo 1.", "Error de entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                esValido = false;
            }

            if (!double.TryParse(tx2.Text, out numero2))
            {
                MessageBox.Show("Ingrese un n�mero v�lido en el campo 2.", "Error de entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                esValido = false;
            }

            return esValido;
        }
        private void sumar_Click(object sender, EventArgs e)
        {
            if (ValidarEntradas(out double numero1, out double numero2))
            {
                double resultado = numero1 + numero2;
                lstHistorial.Items.Add($"Suma: {numero1} + {numero2} = {resultado}");
                LimpiarTextBoxes();
            }

        }

        private void restar_Click(object sender, EventArgs e)
        {
            if (ValidarEntradas(out double numero1, out double numero2))
            {
                double resultado = numero1 - numero2;
                lstHistorial.Items.Add($"Resta: {numero1} - {numero2} = {resultado}");
                LimpiarTextBoxes();
            }

        }

        private void limpiar_Click(object sender, EventArgs e)
        {
            LimpiarTextBoxes();
            lstHistorial.Items.Clear();
        }
        private void LimpiarTextBoxes()
        {
            tx1.Clear();
            tx2.Clear();
            
        }
    }
}
